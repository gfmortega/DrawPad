import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
public class PolyManager extends JFrame
{
	private static final int listLength = 30;
	private int width;
	private int height;
	
	private Container labelPane;
	private JButton newShapeButton;
	
	public ArrayList<PolyLabel> polygonList;
	
	public int currentIndex;
	
	public PolyManager(int w, int h)
	{
		width = w;
		height = h;
		currentIndex = -1;
		polygonList = new ArrayList<PolyLabel>();
	
		setUpNewButton();
	
		labelPane = new Container();
		this.getContentPane().add(labelPane);
		
		makeNewShape("Background");
		
		setUpAppearances();
		
		this.setTitle("Polygon Manager");
		this.setSize(w,h);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setVisible(true);
		
	}
	public void swapPoly(int i)
	{
		polygonList.get(currentIndex).index += i;
		polygonList.get(currentIndex+i).index += -i;
		
		PolyLabel a = polygonList.get(currentIndex);
		polygonList.set(currentIndex,polygonList.get(currentIndex+i));
		polygonList.set(currentIndex+i,a);
		
		currentIndex += i;
	}
	private void makeNewShape(String s)
	{
		Color useColor = Color.BLACK;
		Color useOutline = Color.BLACK;
		if(currentIndex!=-1)
		{
			polygonList.get(currentIndex).setBackground(Color.WHITE);
			useColor = polygonList.get(currentIndex).polygon.getColor();
			useOutline = polygonList.get(currentIndex).polygon.outlineColor;
		}
		
		currentIndex = polygonList.size();
		polygonList.add(new PolyLabel(s, currentIndex, this, useColor,useOutline));
		
		polygonList.get(currentIndex).setBackground(Color.YELLOW);
	}
	private void setUpNewButton()
	{
		newShapeButton = new JButton("New Shape");
		ActionListener newShapeListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				String s = JOptionPane.showInputDialog(null,"Input the name of the new shape.");
				if(s==null)
					return;
				makeNewShape(s);
				setUpAppearances();
			}
		};
		newShapeButton.addActionListener(newShapeListener);
		
		
	}
	public void setUpAppearances()
	{
		labelPane.removeAll();
		labelPane.setLayout(new GridLayout(listLength+1,1));
		
		labelPane.add(newShapeButton);
		
		for(int i = 0; i < polygonList.size(); i++)
			labelPane.add(polygonList.get(i));
			
		for(int i = polygonList.size(); i < listLength; i++)
			labelPane.add(new JLabel(""));
		revalidate();
	}
	public void deleteCurrentShape()
	{
		polygonList.remove(currentIndex);
		for(int i = 0; i < polygonList.size(); i++)
			polygonList.get(i).index = i;
			
		if(polygonList.isEmpty())
			currentIndex = -1;
		else 
		{
			if(currentIndex>0)
				currentIndex--;		
			polygonList.get(currentIndex).setBackground(Color.YELLOW);
		}	
			
		setUpAppearances();
	}
	public void saveState(String s)
	{
		try
		{
			PrintWriter writer = new PrintWriter(new File("Save/"+s+".txt"));
			
			writer.println(currentIndex);
			writer.println(polygonList.size());
			for(int i = 0; i < polygonList.size(); i++)
			{
				Poly p = polygonList.get(i).polygon;
				
				writer.println(polygonList.get(i).getText());
				
				Color c;
				c = p.myColor;
				writer.println(c.getRed() + " " + c.getGreen() + " " + c.getBlue());
				c = p.outlineColor;
				writer.println(c.getRed() + " " + c.getGreen() + " " + c.getBlue());
				
				
				writer.println(p.isFilled);
				writer.println(p.isVisible);
				writer.println(p.isOutline);
				writer.println(p.showPoints);
				
				writer.println(p.pointList.size());
				
				for(int j = 0; j < p.pointList.size(); j++)
					writer.println(p.pointList.get(j).x + " " + p.pointList.get(j).y);
				writer.println(p.actionList.size());
				for(int j = 0; j < p.actionList.size(); j++)
				{
					ActionType an = p.actionList.get(j); 
					if(an.type==0)
						writer.println("0 " + an.val1);
					else if(an.type==1)
						writer.println("1 " + an.val1 + " " + an.val2);
				}		
			}
			
			writer.close();
			
			JOptionPane.showMessageDialog(null,"Save successful.");
		}
		catch(FileNotFoundException fe)
		{
			JOptionPane.showMessageDialog(null,"Saving failed.");
		}
	}
	public void loadState(String s)
	{
		try
		{
			Scanner sc = new Scanner(new File("Save/"+ s+".txt"));
			
			currentIndex = sc.nextInt();
			polygonList.clear();
			
			int polyCount = sc.nextInt();
			for(int i = 0; i < polyCount; i++)
			{
				sc.nextLine(); //consumes newline character
				PolyLabel pL = new PolyLabel(sc.nextLine(), i, this, new Color(sc.nextInt(), sc.nextInt(), sc.nextInt()), new Color(sc.nextInt(), sc.nextInt(), sc.nextInt()));
				Poly p = pL.polygon;
				
				p.isFilled = sc.nextBoolean();
				p.isVisible = sc.nextBoolean();
				p.isOutline = sc.nextBoolean();
				p.showPoints = sc.nextBoolean();
				
				int pointCount = sc.nextInt();
				for(int j = 0; j < pointCount; j++)
					p.pointList.add(new Point(sc.nextInt(), sc.nextInt()));
					
				int actionCount = sc.nextInt();
				for(int j = 0; j < actionCount; j++)
				{
					int t = sc.nextInt();
					if(t==0)
						p.actionList.add(new ActionType(t,sc.nextInt()));
					else if(t==1)
						p.actionList.add(new ActionType(t,sc.nextInt(),sc.nextInt()));
				}
				
				polygonList.add(pL);
			}
			
			for(int i = 0; i < polyCount; i++)
				if(i==currentIndex)
					polygonList.get(i).setBackground(Color.YELLOW);
				else
					polygonList.get(i).setBackground(Color.WHITE);
					
			setUpAppearances();
			sc.close();
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, "An error has occured.  Please make sure the file name is being inputted correctly.\n" + "There is no need to add .txt to the end of the file name");
		}
	}
	public void printState(String s, String ta)
	{
		try
		{
			PrintWriter writer = new PrintWriter(new File("Print/"+s+".txt"));
			
			int t = Integer.parseInt(ta);
			String tabs = "";
			for(int j = 0; j < t; j++)
				tabs += "\t";
			for(int j = 0; j < polygonList.size(); j++)
			{
				Poly p = polygonList.get(j).polygon;
				
				if(p.pointList.isEmpty())
					continue;
				if(!p.isVisible)
					continue;
					
				writer.println(tabs+"Path2D.Double p"+j+" = new Path2D.Double();");
				writer.println(tabs+"p"+j+".moveTo(x+" + p.pointList.get(0).x + ", y+" + p.pointList.get(0).y + ");");
				for(int i = 1; i < p.pointList.size(); i++)
					writer.println(tabs+"p"+j+".lineTo(x+" + p.pointList.get(i).x + ", y+" + p.pointList.get(i).y + ");");
					
				Color c = p.outlineColor;
				writer.println(tabs+"g2d.setColor(new Color(" +c.getRed() + ", " + c.getGreen() + ", " + c.getBlue() + "));");
				if(p.isOutline)
					writer.println(tabs+"g2d.draw(p"+j+");");
				
				c = p.myColor;
				writer.println(tabs+"g2d.setColor(new Color(" +c.getRed() + ", " + c.getGreen() + ", " + c.getBlue() + "));");
				if(p.isFilled)
					writer.println(tabs+"g2d.fill(p"+j+");");
			}
			
			writer.close();
			JOptionPane.showMessageDialog(null, "Printing successful.");
		}
		catch(FileNotFoundException fe)
		{
			JOptionPane.showMessageDialog(null,"Printing failed.  Make sure inputted number of tabs is an integer.");
		}
	}
	public void printStateBasicShape(String s, String ta)
	{
		try
		{
			PrintWriter writer = new PrintWriter(new File("Print/"+s+".txt"));
			
			int t = Integer.parseInt(ta);
			String tabs = "";
			for(int j = 0; j < t; j++)
				tabs += "\t";
			for(int j = 0; j < polygonList.size(); j++)
			{
				Poly p = polygonList.get(j).polygon;
				
				if(p.pointList.isEmpty())
					continue;
				if(!p.isVisible)
					continue;
					
				writer.println(tabs+"Path2D.Double p"+j+" = new Path2D.Double();");
				writer.println(tabs+"p"+j+".moveTo(x+" + p.pointList.get(0).x + ", y+" + p.pointList.get(0).y + ");");
				for(int i = 1; i < p.pointList.size(); i++)
					writer.println(tabs+"p"+j+".lineTo(x+" + p.pointList.get(i).x + ", y+" + p.pointList.get(i).y + ");");
					
				Color c = p.outlineColor;
				writer.println(tabs+"g2d.setColor(new Color(" +c.getRed() + ", " + c.getGreen() + ", " + c.getBlue() + "));");
				if(p.isOutline)
					writer.println(tabs+"g2d.draw(p"+j+");");
				
				c = p.myColor;
				writer.println(tabs+"g2d.setColor(new Color(" +c.getRed() + ", " + c.getGreen() + ", " + c.getBlue() + "));");
				if(p.isFilled)
					writer.println(tabs+"g2d.fill(p"+j+");");
			}
			
			writer.close();
			JOptionPane.showMessageDialog(null, "Printing successful.");
		}
		catch(FileNotFoundException fe)
		{
			JOptionPane.showMessageDialog(null,"Printing failed.  Make sure inputted number of tabs is an integer.");
		}
	}

}






