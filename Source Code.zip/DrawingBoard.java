import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.*;
public class DrawingBoard extends JComponent
{
	private int width;
	private int height;
	private PolyManager manager;
	
	public DrawingBoard(int w, int h, PolyManager p)
	{
		width = w;
		height = h;
		manager = p;
		
		MouseListener m = new MouseListener()
		{			
			@Override
			public void mousePressed(MouseEvent me)
			{
				if(manager.polygonList.isEmpty())
					return;
				int x = me.getX();
				int y = me.getY();
				manager.polygonList.get(manager.currentIndex).polygon.addPoint(x,y,true,false);
				
				repaint();
			}
			@Override
			public void mouseClicked(MouseEvent me){}
			@Override
			public void mouseEntered(MouseEvent me){}
			@Override
			public void mouseReleased(MouseEvent me){}
			@Override
			public void mouseExited(MouseEvent me){}
		};
		MouseMotionListener mM = new MouseMotionListener()
		{
			@Override
			public void mouseDragged(MouseEvent me)
			{
				if(manager.polygonList.isEmpty())
					return;
				int x = me.getX();
				int y = me.getY();
				manager.polygonList.get(manager.currentIndex).polygon.addPoint(x,y,false,false);
				repaint();
			}
			@Override
			public void mouseMoved(MouseEvent me){}
		};
		
		this.setBackground(Color.WHITE);
		this.addMouseListener(m);
		this.addMouseMotionListener(mM);
	}
	protected void paintComponent(Graphics g)
	{
		Graphics2D g2d = (Graphics2D)g;
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);
		
		
		for(int i = 0; i < manager.polygonList.size(); i++)
			manager.polygonList.get(i).polygon.draw(g2d);
			
	}
}