public class DrawPad
{
	public static void main(String[] args)
	{
		PolyManager p = new PolyManager(150,768);
		DrawingBoard db = new DrawingBoard(1024,768,p);
		DrawingFrame d = new DrawingFrame(1024,768,p,db);
		AdjusterFrame af = new AdjusterFrame(275,150,p,db);
	}
}