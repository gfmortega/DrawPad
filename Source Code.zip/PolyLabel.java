import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class PolyLabel extends JButton
{
	public Poly polygon;
	public int index;
	private PolyManager manager;
	public PolyLabel(String s, int i, PolyManager p, Color c, Color o)
	{
		super(s);
		index = i;
		manager = p;
		polygon = new Poly(c,o);
		ActionListener a = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				manager.polygonList.get(manager.currentIndex).setBackground(Color.WHITE);
				manager.currentIndex = index;
				manager.polygonList.get(manager.currentIndex).setBackground(Color.YELLOW);
			}
		};
		
		this.addActionListener(a);
	}
}