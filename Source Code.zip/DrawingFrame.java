import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DrawingFrame extends JFrame
{
	private int width;
	private int height;
	private PolyManager manager;
	private DrawingBoard board;
	
	private Container contentPane;
	private Container topPane;
	private Container bottomPane;
	
	private JButton setColorButton;
	private JButton setOutlineButton;
	private JTextField redTextField;
	private JTextField greenTextField;
	private JTextField blueTextField;
	private JButton takeColorButton;
	private JButton takeOutlineButton;
	
	private Container undoRedoButtons;
	private JButton redoButton;
	private JButton undoButton;
	
	private Container drawButtons;
	private JButton fillButton;
	private JButton outlineButton;
	
	private Container showButtons;
	private JButton showPointsButton;
	private JButton showShapeButton;
	
	private JButton deleteShapeButton;
	
	private Container backAndFwdButtons;
	private JButton backButton;
	private JButton fwdButton;
	
	private Container fileButtons;
	private JButton saveButton;
	private JButton loadButton;
	private JButton printButton;
	
	public DrawingFrame(int w, int h, PolyManager p, DrawingBoard db)
	{
		width = w;
		height = h;
		manager = p;
		board = db;
		
		contentPane = this.getContentPane();
		topPane = new Container();
		bottomPane = new Container();
		
		setUpTopPane();
		setUpBottomPane();
		
		contentPane.add(topPane, BorderLayout.NORTH);
		contentPane.add(bottomPane, BorderLayout.SOUTH);
		contentPane.add(db, BorderLayout.CENTER);
		
		this.setSize(w,h);
		this.setTitle("Draw Pad");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	private void setUpTopPane()
	{
		topPane.setLayout(new GridLayout(1,7));
		
		setColorButton = new JButton("Set Color");
		ActionListener setColorListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				try
				{
					int R = Integer.parseInt(redTextField.getText());
					int G = Integer.parseInt(greenTextField.getText());
					int B = Integer.parseInt(blueTextField.getText());
					manager.polygonList.get(manager.currentIndex).polygon.setColor(new Color(R,G,B));
					repaint();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null,"Please make sure the inputted values are integers in the range [0,255]");
				}
			}
		};
		setColorButton.addActionListener(setColorListener);
		
		setOutlineButton = new JButton("Outline Color");
		ActionListener setOutlineListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				try
				{
					int R = Integer.parseInt(redTextField.getText());
					int G = Integer.parseInt(greenTextField.getText());
					int B = Integer.parseInt(blueTextField.getText());
					manager.polygonList.get(manager.currentIndex).polygon.outlineColor = new Color(R,G,B);
					repaint();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null,"Please make sure the inputted values are integers in the range [0,255]");
				}
			}
		};
		setOutlineButton.addActionListener(setOutlineListener);
		
		redTextField = new JTextField("0");
		greenTextField = new JTextField("0");
		blueTextField = new JTextField("0");
		
		redTextField.setHorizontalAlignment(JTextField.CENTER);
		greenTextField.setHorizontalAlignment(JTextField.CENTER);
		blueTextField.setHorizontalAlignment(JTextField.CENTER);
		
		takeColorButton = new JButton("Take Current Fill");
		ActionListener takeColorListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex<0)
					return;
				Color c = manager.polygonList.get(manager.currentIndex).polygon.getColor();
				redTextField.setText(""+c.getRed());
				greenTextField.setText(""+c.getGreen());
				blueTextField.setText(""+c.getBlue());
			}
		};
		takeColorButton.addActionListener(takeColorListener);
		
		takeOutlineButton = new JButton("Take Current Outline");
		ActionListener takeListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex<0)
					return;
				Color c = manager.polygonList.get(manager.currentIndex).polygon.outlineColor;
				redTextField.setText(""+c.getRed());
				greenTextField.setText(""+c.getGreen());
				blueTextField.setText(""+c.getBlue());
			}
		};
		takeOutlineButton.addActionListener(takeListener);
		
		topPane.add(setColorButton);
		topPane.add(setOutlineButton);
		topPane.add(redTextField);
		topPane.add(greenTextField);
		topPane.add(blueTextField);
		topPane.add(takeColorButton);
		topPane.add(takeOutlineButton);
	}
	private void setUpBottomPane()
	{
		bottomPane.setLayout(new GridLayout(3,2));
		
		undoRedoButtons = new Container();
		undoRedoButtons.setLayout(new GridLayout(1,2));
		
		undoButton = new JButton("Undo");
		ActionListener undoListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				manager.polygonList.get(manager.currentIndex).polygon.undo();
				board.repaint();
			}
		};
		undoButton.addActionListener(undoListener);
		
		redoButton = new JButton("Redo");
		ActionListener redoListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				manager.polygonList.get(manager.currentIndex).polygon.redo();
				board.repaint();
			}
		};
		redoButton.addActionListener(redoListener);
		
		drawButtons = new Container();
		drawButtons.setLayout(new GridLayout(1,2));
		
		fillButton = new JButton("Fill");
		ActionListener fillListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				manager.polygonList.get(manager.currentIndex).polygon.flipIsFilled();
				board.repaint();
			}
		};
		fillButton.addActionListener(fillListener);
		
		outlineButton = new JButton("Outline");
		ActionListener outlineListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				manager.polygonList.get(manager.currentIndex).polygon.flipOutline();
				board.repaint();
			}
		};
		outlineButton.addActionListener(outlineListener);
		
		showButtons = new Container();
		showButtons.setLayout(new GridLayout(1,2));
		
		showPointsButton = new JButton("Show Points");
		ActionListener showListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex<0)
					return;
				manager.polygonList.get(manager.currentIndex).polygon.flipShowPoints();
				board.repaint();
			}
		};
		showPointsButton.addActionListener(showListener);
		
		showShapeButton = new JButton("Show Shape");
		ActionListener showShapeListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex<0)
					return;
				manager.polygonList.get(manager.currentIndex).polygon.flipVisible();
				board.repaint();
			}
		};
		showShapeButton.addActionListener(showShapeListener);
		
		deleteShapeButton = new JButton("Delete");
		ActionListener deleteListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				
				if(manager.polygonList.size()==0)
					JOptionPane.showMessageDialog(null,"There is no active polygon.");
				else
				{
					int ans = JOptionPane.showConfirmDialog(null,"Are you sure you want to delete this polygon?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
					if(ans==JOptionPane.YES_OPTION)
					{
						manager.deleteCurrentShape();
						board.repaint();
					}
				}
			}
		};
		deleteShapeButton.addActionListener(deleteListener);
		
		backAndFwdButtons = new Container();
		backAndFwdButtons.setLayout(new GridLayout(1,2));
		
		backButton = new JButton("Back");
		ActionListener backListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex==0 || manager.currentIndex==-1)
					return;	
				
				manager.swapPoly(-1);
				manager.setUpAppearances();
				
				repaint();
			}
		};
		backButton.addActionListener(backListener);
		
		fwdButton = new JButton("Forward");
		ActionListener fwdListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				if(manager.currentIndex==manager.polygonList.size()-1)
					return;	
					
				manager.swapPoly(1);
				manager.setUpAppearances();
				
				repaint();
			}
		};
		fwdButton.addActionListener(fwdListener);
		
		fileButtons = new Container();
		fileButtons.setLayout(new GridLayout(1,3));
		
		saveButton = new JButton("Save");
		ActionListener saveListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				String s = JOptionPane.showInputDialog(null,"Input name of save file.");
				if(s==null)
					return;
				manager.saveState(s);
			}
		};
		saveButton.addActionListener(saveListener);
		
		loadButton = new JButton("Load");
		ActionListener loadListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				String s = JOptionPane.showInputDialog(null,"Input name of file to be loaded.");
				if(s==null)
					return;
				manager.loadState(s);
				repaint();
			}
		};
		loadButton.addActionListener(loadListener);
		
		printButton = new JButton("Print");
		ActionListener printListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				String s = JOptionPane.showInputDialog(null,"Input name of file to print code to.");
				String t = JOptionPane.showInputDialog(null,"Input number of tabs which will precede these lines.");
				if(s==null)
					return;
				manager.printStateBasicShape(s,t);
			}
		};
		printButton.addActionListener(printListener);
		
		undoRedoButtons.add(undoButton);
		undoRedoButtons.add(redoButton);
		bottomPane.add(undoRedoButtons);
		
		drawButtons.add(fillButton);
		drawButtons.add(outlineButton);
		bottomPane.add(drawButtons);
		
		showButtons.add(showPointsButton);
		showButtons.add(showShapeButton);
		bottomPane.add(showButtons);
		
		bottomPane.add(deleteShapeButton);
		
		backAndFwdButtons.add(backButton);
		backAndFwdButtons.add(fwdButton);
		bottomPane.add(backAndFwdButtons);
		
		fileButtons.add(saveButton);
		fileButtons.add(loadButton);
		fileButtons.add(printButton);
		bottomPane.add(fileButtons);
	}
	
}