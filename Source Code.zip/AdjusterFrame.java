import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AdjusterFrame extends JFrame
{
	private int width;
	private int height;
	private PolyManager manager;
	private DrawingBoard board;
	
	private Container contentPane;
	private JTextField pixelLeapField;
	private JButton upButton;
	private JButton downButton;
	private JButton leftButton;
	private JButton rightButton;
	private JButton moveAllButton;
	
	private boolean moveAll;
	
	public AdjusterFrame(int w, int h, PolyManager p, DrawingBoard db)
	{
		width = w;
		height = h;
		manager = p;
		board = db;
		
		moveAll = false;
		
		contentPane = this.getContentPane();
		contentPane.setLayout(new GridLayout(2,3));
		
		setUpButtons();
		
		this.setTitle("Adjust Polygon");
		this.setSize(w,h);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setVisible(true);
	}
	private class sendMovementListener implements ActionListener
	{
		private int x;
		private int y;
		public sendMovementListener(int i, int j)
		{
			x = i;
			y = j;
		}
		@Override
		public void actionPerformed(ActionEvent ae)
		{
			try
			{
				int pixelLeap = Integer.parseInt(pixelLeapField.getText());
				if(moveAll)
					for(int i = 0; i < manager.polygonList.size(); i++)
						manager.polygonList.get(i).polygon.adjustPoints(pixelLeap*x,pixelLeap*y,true,false);
				else
					manager.polygonList.get(manager.currentIndex).polygon.adjustPoints(pixelLeap*x,pixelLeap*y,true,false);
				board.repaint();
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,"Make sure the pixel movement value is correct");
			}
		}
	};
	private void setUpButtons()
	{
		pixelLeapField = new JTextField("5");
		pixelLeapField.setHorizontalAlignment(JTextField.CENTER);
		
		upButton = new JButton("UP");
		upButton.addActionListener(new sendMovementListener(0,-1));
		downButton = new JButton("DOWN");
		downButton.addActionListener(new sendMovementListener(0,1));
		leftButton = new JButton("LEFT");
		leftButton.addActionListener(new sendMovementListener(-1,0));
		rightButton = new JButton("RIGHT");
		rightButton.addActionListener(new sendMovementListener(1,0));
		
		moveAllButton = new JButton("Move All");
		ActionListener moveListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				moveAll = !moveAll;
			}
		};
		moveAllButton.addActionListener(moveListener);
		
		contentPane.add(pixelLeapField);
		contentPane.add(upButton);
		contentPane.add(moveAllButton);
		contentPane.add(leftButton);
		contentPane.add(downButton);
		contentPane.add(rightButton);
		
	}
}