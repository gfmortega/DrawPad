import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
public class Poly
{
	public ArrayList<Point> pointList;
	public ArrayList<ActionType> actionList;
	
	public Stack<Point> deletedPoints;
	public Queue<ActionType> pendingDeletionActions;
	
	public boolean isFilled;
	public boolean isOutline;
	public boolean isVisible;
	
	public boolean showPoints;
	public Color myColor;
	public Color outlineColor;
	
	public Poly(Color c, Color o)  
	{
		pointList = new ArrayList<Point>();
		actionList = new ArrayList<ActionType>();
		deletedPoints = new Stack<Point>();
		pendingDeletionActions = new LinkedList<ActionType>();
		
		myColor = c;
		outlineColor = o;
		isOutline = true;
		isFilled = false;
		isVisible = true;
		showPoints = false;
	}
	public void undo()
	{
		if(actionList.isEmpty())
			return;
			
		ActionType at = actionList.get(actionList.size()-1);
		
		if(at.type==0)
		{
			pendingDeletionActions.add(new ActionType(0,pointList.size()-actionList.get(actionList.size()-1).val1));
			popPoints();
		}
		else if(at.type==1)
		{
			pendingDeletionActions.add(new ActionType(1,at.val1, at.val2));
			adjustPoints(-at.val1,-at.val2,false,true);
		}	
		actionList.remove(actionList.size()-1);
	}
	public void redo()
	{
		if(pendingDeletionActions.isEmpty())
			return;
			
		ActionType at = pendingDeletionActions.remove();
		
		if(at.type==0)
		{
			Point firstPoint = deletedPoints.pop();
			addPoint(firstPoint.x,firstPoint.y,true,true);
			for(int i = 1; i < at.val1; i++)
			{
				Point pt = deletedPoints.pop();
				addPoint(pt.x,pt.y,false,true);
			}
		}
		else if(at.type==1)
			adjustPoints(at.val1,at.val2,true,true);
	}
	public void adjustPoints(int x, int y, boolean buttonPushed, boolean redone)
	{
		if(pointList.isEmpty())
			return;
		
		if(!redone)
		{
			deletedPoints.clear();
			pendingDeletionActions.clear();
		}
		
		for(int i = 0; i < pointList.size(); i++)
		{
			pointList.get(i).x += x;
			pointList.get(i).y += y;
		}
		if(buttonPushed)
			actionList.add(new ActionType(1,x,y));
	}
	public void addPoint(int x, int y, boolean newClick, boolean redone)
	{
		if(!redone)
		{
			deletedPoints.clear();
			pendingDeletionActions.clear();
		}
		
		if(newClick)
			actionList.add(new ActionType(0,pointList.size()));
		pointList.add(new Point(x,y));
	}
	public void popPoints()
	{
		if(!actionList.isEmpty())
		{
			while(pointList.size() > actionList.get(actionList.size()-1).val1 )
			{
				Point pt = pointList.get(pointList.size()-1);
				deletedPoints.push(new Point(pt.x,pt.y));
				pointList.remove(pointList.size()-1);
			}
		}
	}
	public void draw(Graphics2D g2d)
	{
		if(!isVisible)
			return;
			
		Path2D.Double p = new Path2D.Double();
		
		g2d.setColor(Color.BLACK);
		for(int i = 0; i < pointList.size(); i++)
		{
			if(i==0)
				p.moveTo(pointList.get(i).x, pointList.get(i).y);
			else
				p.lineTo(pointList.get(i).x, pointList.get(i).y);
				
			if(i==pointList.size()-1)
				g2d.setColor(Color.GREEN);
			if(showPoints)
				g2d.fillOval(pointList.get(i).x-3,pointList.get(i).y-3,6,6);
		}
		
		g2d.setColor(myColor);
		if(isFilled)
			g2d.fill(p);
			
		g2d.setColor(outlineColor);
		if(isOutline)
			g2d.draw(p);
		
		
	}
	public void flipIsFilled()
	{
		isFilled = !isFilled;
	}
	public void flipShowPoints()
	{
		showPoints = !showPoints;
	}
	public void flipOutline()
	{
		isOutline = !isOutline;
	}
	public void flipVisible()
	{
		isVisible = !isVisible;
	}
	public void setColor(Color c)
	{
		myColor = c;
	}
	public Color getColor()
	{
		return myColor;
	}
}