public class ActionType
	{
		public int type;
		/*
			t = 0: points added to path that used to be of size val1
			t = 1: path was translated by val1 down and by val2 right
		*/
		public int val1, val2;
		public ActionType(int t, int v)
		{
			type = t;
			val1 = v;
		}
		public ActionType(int t, int v1, int v2)
		{
			type = t;
			val1 = v1;
			val2 = v2;
		}
	}